import sqlite3
import os

DB_PATH = os.path.join("data", "variables.db")

def init_db():
    os.makedirs("data", exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS variables (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            value TEXT,
            description TEXT
        )
    """)
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS tools (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            version TEXT,
            description TEXT
        )
    """)
    conn.commit()
    conn.close()

def get_all_variables():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, value, description FROM variables")
    rows = cursor.fetchall()
    conn.close()
    return rows

def insert_variable(name, value, description):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO variables (name, value, description) VALUES (?, ?, ?)",
                   (name, value, description))
    conn.commit()
    conn.close()

def update_variable(var_id, name, value, description):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("UPDATE variables SET name=?, value=?, description=? WHERE id=?",
                   (name, value, description, var_id))
    conn.commit()
    conn.close()

def delete_variable(var_id):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM variables WHERE id=?", (var_id,))
    conn.commit()
    conn.close()

def clear_tools():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM tools")
    conn.commit()
    conn.close()

def get_all_tools():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, name, version, description FROM tools")
    rows = cursor.fetchall()
    conn.close()
    return rows

def insert_tool(name, version, description):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO tools (name, version, description) VALUES (?, ?, ?)",
                   (name, version, description))
    conn.commit()
    conn.close()


def get_all_process_steps():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, step_text, doc_path FROM process_steps")
    rows = cursor.fetchall()
    conn.close()
    return rows

def insert_process_step(step_text, doc_path):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO process_steps (step_text, doc_path) VALUES (?, ?)", (step_text, doc_path))
    conn.commit()
    conn.close()

def clear_process_steps():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM process_steps")
    conn.commit()
    conn.close()


def get_all_faqs():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS faqs (id INTEGER PRIMARY KEY AUTOINCREMENT, question TEXT, answer TEXT)")
    cursor.execute("SELECT id, question, answer FROM faqs")
    rows = cursor.fetchall()
    conn.close()
    return rows

def insert_faq(question, answer):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO faqs (question, answer) VALUES (?, ?)", (question, answer))
    conn.commit()
    conn.close()

def clear_faqs():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM faqs")
    conn.commit()
    conn.close()


def get_all_filepaths():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("CREATE TABLE IF NOT EXISTS filepaths (id INTEGER PRIMARY KEY AUTOINCREMENT, description TEXT, path TEXT)")
    cursor.execute("SELECT description, path FROM filepaths")
    rows = cursor.fetchall()
    conn.close()
    return rows

def insert_filepath(description, path):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO filepaths (description, path) VALUES (?, ?)", (description, path))
    conn.commit()
    conn.close()

def clear_filepaths():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM filepaths")
    conn.commit()
    conn.close()
