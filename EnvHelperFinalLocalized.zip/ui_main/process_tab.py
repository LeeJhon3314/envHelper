from PyQt5.QtWidgets import QWidget, QVBoxLayout, QScrollArea, QFrame, QHBoxLayout, QLabel, QLineEdit, QPushButton, QFileDialog, QSizePolicy, QMessageBox
from PyQt5.QtCore import QUrl, QSize
from PyQt5.QtGui import QDesktopServices, QIcon
from .shared import normalize_input
import os, shutil, uuid
import database

class ProcessTabMixin:
    def build_process_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(500)

        container = QWidget()
        self.flow_layout = QVBoxLayout(container)
        self.flow_layout.setSpacing(10)
        container.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        scroll.setWidget(container)

        for step in database.get_all_process_steps():
            self.add_process_row(step_text=step[1], doc_path=step[2])

        if not self.flow_blocks:
            for _ in range(3):
                self.add_process_row()

        add_button = QPushButton("追加步驟")
        add_button.clicked.connect(self.add_process_row)

        save_button = QPushButton("儲存作業流程")
        save_button.clicked.connect(self.save_process_steps)

        layout.addWidget(scroll)
        layout.addWidget(add_button)
        layout.addWidget(save_button)
        widget.setLayout(layout)
        return widget

    def add_process_row(self, step_text="", doc_path=""):
        frame = QFrame()
        frame.setFrameShape(QFrame.StyledPanel)
        frame.setFixedHeight(60)

        layout = QHBoxLayout()
        layout.setSpacing(10)

        index_label = QLabel(f"{len(self.flow_blocks) + 1}.")

        step_input = QLineEdit(normalize_input(step_text))
        step_input.setPlaceholderText("步驟內容")
        step_input.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        file_label = QPushButton("流程文件" if doc_path else "尚未選擇")
        file_label.setEnabled(bool(doc_path))
        file_label.clicked.connect(lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(doc_path)) if doc_path else None)

        browse_button = QPushButton()
        browse_button.setIcon(QIcon("assets/icons/1f4ce.png"))
        browse_button.setIconSize(QSize(24, 24))

        def choose_file():
            nonlocal doc_path
            file_dialog, _ = QFileDialog.getOpenFileName(None, "選擇 Word 檔案", "", "Word Files (*.doc *.docx)")
            if file_dialog:
                unique_name = str(uuid.uuid4()) + "_" + os.path.basename(file_dialog)
                dest_path = os.path.join("assets", "docs", unique_name)
                shutil.copy(file_dialog, dest_path)
                doc_path = dest_path
                file_label.setText("流程文件")
                file_label.setEnabled(True)

        browse_button.clicked.connect(choose_file)

        delete_btn = QPushButton("🗑️")

        layout.addWidget(index_label)
        layout.addWidget(step_input, 6)
        layout.addWidget(file_label, 2)
        layout.addWidget(browse_button, 1)
        layout.addWidget(delete_btn, 1)

        frame.setLayout(layout)

        def get_path():
            return doc_path

        def remove():
            path = get_path()
            if path and os.path.exists(path):
                try:
                    os.remove(path)
                except Exception as e:
                    print(f"無法刪除文件: {e}")
            frame.setParent(None)
            self.flow_blocks = [b for b in self.flow_blocks if b[0] != frame]
            self.refresh_flow_numbers()

        self.flow_blocks.append((frame, index_label, step_input, file_label, browse_button, delete_btn, get_path))
        delete_btn.clicked.connect(remove)
        self.flow_layout.addWidget(frame)

    def refresh_flow_numbers(self):
        for idx, (_, label, *_ ) in enumerate(self.flow_blocks):
            label.setText(f"{idx+1}.")

    def save_process_steps(self):
        database.clear_process_steps()
        for (_, _, step_input, _, _, _, get_path) in self.flow_blocks:
            step = step_input.text().strip()
            doc = get_path()
            if step:
                database.insert_process_step(step, doc)
        QMessageBox.information(self, "儲存成功", "作業流程與文件已成功儲存至資料庫。")
