from PyQt5.QtWidgets import QWidget, QVBoxLayout, QScrollArea, QFrame, QLabel, QLineEdit, QPushButton, QHBoxLayout, QSizePolicy, QMessageBox
from .shared import normalize_input
import database

class ToolsTabMixin:
    def build_tools_tab(self):
        self.tool_blocks = []

        widget = QWidget()
        layout = QVBoxLayout(widget)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)

        container = QWidget()
        container_layout = QVBoxLayout(container)
        container_layout.setSpacing(10)
        container.setLayout(container_layout)
        scroll.setWidget(container)

        self.tools_layout = container_layout  # 指向 container 裡的 layout

        tools = database.get_all_tools()
        if tools:
            for t in tools:
                self.add_tool_row(name=t[1], version=t[2], desc=t[3])
        else:
            for _ in range(3):
                self.add_tool_row()

        add_button = QPushButton("追加工具")
        add_button.clicked.connect(self.add_tool_row)

        save_button = QPushButton("儲存工具")
        save_button.clicked.connect(self.save_tools)

        title_row = QHBoxLayout()
        title_row.addWidget(QLabel("工具名稱"), 1)
        title_row.addWidget(QLabel("版本"), 1)
        title_row.addWidget(QLabel("說明"), 2)
        layout.addLayout(title_row)

        layout.addWidget(scroll)
        layout.addWidget(add_button)
        layout.addWidget(save_button)

        return widget

    def add_tool_row(self, name="", version="", desc=""):
        frame = QFrame()
        frame.setFrameShape(QFrame.StyledPanel)
        frame.setFixedHeight(90)

        layout = QHBoxLayout()
        layout.setSpacing(10)

        index_label = QLabel(f"{len(self.tool_blocks) + 1}.")

        name_input = QLineEdit(normalize_input(name))
        name_input.setPlaceholderText("工具名稱")

        version_input = QLineEdit(normalize_input(version))
        version_input.setPlaceholderText("版本")

        desc_input = QLineEdit(normalize_input(desc))
        desc_input.setPlaceholderText("說明")
        desc_input.setMaximumWidth(400)
        desc_input.setFixedHeight(30)
        desc_input.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        delete_btn = QPushButton("🗑️")

        layout.addWidget(index_label)
        layout.addWidget(name_input, 1)
        layout.addWidget(version_input, 1)
        layout.addWidget(desc_input, 2)
        layout.addWidget(delete_btn)

        frame.setLayout(layout)
        self.tool_blocks.append((frame, index_label, name_input, version_input, desc_input, delete_btn))

        def remove():
            frame.setParent(None)
            self.tool_blocks = [b for b in self.tool_blocks if b[0] != frame]
            self.refresh_tool_numbers()

        delete_btn.clicked.connect(remove)
        self.tools_layout.addWidget(frame)

    def refresh_tool_numbers(self):
        for idx, (_, label, *_ ) in enumerate(self.tool_blocks):
            label.setText(f"{idx+1}.")

    def save_tools(self):
        database.clear_tools()
        for (_, _, name_input, version_input, desc_input, _) in self.tool_blocks:
            name = name_input.text()
            version = version_input.text()
            desc = desc_input.text()
            if name.strip():
                database.insert_tool(name, version, desc)
        QMessageBox.information(None, "儲存成功", "工具清單已成功儲存到資料庫！")
