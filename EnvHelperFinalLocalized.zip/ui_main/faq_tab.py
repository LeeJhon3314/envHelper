from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QScrollArea, QFrame,
    QHBoxLayout, QLabel, QLineEdit, QTextEdit,
    QPushButton, QSizePolicy, QMessageBox
)
from PyQt5.QtCore import Qt
from .shared import normalize_input
import database

class FaqTabMixin:
    def build_faq_tab(self):
        self.faq_blocks = []

        widget = QWidget()
        layout = QVBoxLayout()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(500)

        container = QWidget()
        self.faq_layout = QVBoxLayout(container)
        self.faq_layout.setSpacing(10)
        container.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        scroll.setWidget(container)

        for _, q, a in database.get_all_faqs():
            self.add_faq_row(q, a)

        if not self.faq_blocks:
            for _ in range(3):
                self.add_faq_row()

        add_button = QPushButton("追加常見問題")
        add_button.clicked.connect(self.add_faq_row)

        save_button = QPushButton("儲存常見問題")
        save_button.clicked.connect(self.save_faq)

        layout.addWidget(scroll)
        layout.addWidget(add_button)
        layout.addWidget(save_button)
        widget.setLayout(layout)
        return widget

    def add_faq_row(self, question_text="", answer_text=""):
        frame = QFrame()
        frame.setFrameShape(QFrame.StyledPanel)

        layout = QVBoxLayout()
        layout.setSpacing(6)

        top_row = QHBoxLayout()
        index_label = QLabel(f"{len(self.faq_blocks) + 1}.")

        question_input = QLineEdit(normalize_input(question_text))
        question_input.setPlaceholderText("問題")
        question_input.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        top_row.addWidget(index_label)
        top_row.addWidget(question_input, 2)

        answer_input = QTextEdit()
        answer_input.setPlainText(normalize_input(answer_text))
        answer_input.setPlaceholderText("說明")
        answer_input.setFixedHeight(200)
        answer_input.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        answer_input.setLineWrapMode(QTextEdit.WidgetWidth)

        delete_btn = QPushButton("🗑️")
        delete_btn.clicked.connect(lambda: self.remove_faq_row(frame))

        layout.addLayout(top_row)
        layout.addWidget(answer_input)
        layout.addWidget(delete_btn, alignment=Qt.AlignRight)

        frame.setLayout(layout)
        self.faq_layout.addWidget(frame)
        self.faq_blocks.append((frame, index_label, question_input, answer_input))

    def remove_faq_row(self, frame):
        self.faq_blocks = [b for b in self.faq_blocks if b[0] != frame]
        frame.setParent(None)
        self.refresh_faq_numbers()

    def refresh_faq_numbers(self):
        for idx, (_, label, *_ ) in enumerate(self.faq_blocks):
            label.setText(f"{idx + 1}.")

    def save_faq(self):
        database.clear_faqs()
        for (_, _, q_input, a_input) in self.faq_blocks:
            q = q_input.text().strip()
            a = a_input.toPlainText().strip()
            if q:
                database.insert_faq(q, a)
        QMessageBox.information(self, "儲存成功", "常見問題已成功儲存到資料庫。")
