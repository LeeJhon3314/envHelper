from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QScrollArea, QFrame,
    QHBoxLayout, QLabel, QLineEdit, QPushButton,
    QSizePolicy, QMessageBox
)
from PyQt5.QtCore import Qt
from .shared import normalize_input
import database

class FilepathsTabMixin:
    def build_filepaths_tab(self):
        self.path_blocks = []

        widget = QWidget()
        layout = QVBoxLayout()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)

        container = QWidget()
        self.filepaths_layout = QVBoxLayout(container)
        self.filepaths_layout.setSpacing(10)
        container.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        scroll.setWidget(container)

        # 標題列
        title_row = QHBoxLayout()
        title_row.addWidget(QLabel("說明"), 2)
        title_row.addWidget(QLabel("路徑"), 3)
        layout.addLayout(title_row)

        for desc, path in database.get_all_filepaths():
            self.add_path_row(desc, path)

        if not self.path_blocks:
            for _ in range(3):
                self.add_path_row()

        add_button = QPushButton("追加路徑")
        add_button.clicked.connect(self.add_path_row)

        save_button = QPushButton("儲存路徑")
        save_button.clicked.connect(self.save_filepaths)

        layout.addWidget(scroll)
        layout.addWidget(add_button)
        layout.addWidget(save_button)
        widget.setLayout(layout)
        return widget

    def add_path_row(self, desc_text="", path_text=""):
        frame = QFrame()
        frame.setFrameShape(QFrame.StyledPanel)
        frame.setFixedHeight(90)

        layout = QHBoxLayout()
        layout.setSpacing(10)

        desc_input = QLineEdit(normalize_input(desc_text))
        desc_input.setPlaceholderText("說明")
        desc_input.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        path_input = QLineEdit(normalize_input(path_text))
        path_input.setPlaceholderText("路徑")
        path_input.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        delete_btn = QPushButton("🗑️")

        layout.addWidget(desc_input, 2)
        layout.addWidget(path_input, 3)
        layout.addWidget(delete_btn)

        frame.setLayout(layout)
        self.path_blocks.append((frame, desc_input, path_input, delete_btn))
        self.filepaths_layout.addWidget(frame)

        def remove():
            frame.setParent(None)
            self.path_blocks = [b for b in self.path_blocks if b[0] != frame]

        delete_btn.clicked.connect(remove)

    def save_filepaths(self):
        database.clear_filepaths()
        for (_, desc_input, path_input, _) in self.path_blocks:
            desc = desc_input.text().strip()
            path = path_input.text().strip()
            if path:
                database.insert_filepath(desc, path)
        QMessageBox.information(None, "儲存成功", "檔案路徑已成功儲存至資料庫！")
