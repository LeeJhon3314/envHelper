from PyQt5.QtWidgets import QWidget, QVBoxLayout, QScrollArea, QFrame, QVBoxLayout, QLabel, QLineEdit, QPushButton, QGridLayout
from PyQt5.QtCore import Qt
from .shared import normalize_input
import database

class EnvTabMixin:
    def build_env_tab(self):
        self.env_grid = QGridLayout()
        main_widget = QWidget()
        main_layout = QVBoxLayout()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(500)
        content_widget = QWidget()
        self.env_grid.setSpacing(20)
        content_widget.setLayout(self.env_grid)
        scroll.setWidget(content_widget)

        variables = database.get_all_variables()
        if variables:
            for var in variables:
                self.add_env_block(var_id=var[0], name=var[1], value=var[2], desc=var[3])
        else:
            for _ in range(3):
                self.add_env_block()

        add_button = QPushButton("追加變量")
        add_button.clicked.connect(self.add_env_block)
        save_button = QPushButton("儲存變量")
        save_button.clicked.connect(self.save_all_variables)

        main_layout.addWidget(scroll)
        main_layout.addWidget(add_button)
        main_layout.addWidget(save_button)
        main_widget.setLayout(main_layout)
        return main_widget

    def add_env_block(self, var_id=None, name="", value="", desc=""):
        block = QFrame()
        block.setFrameShape(QFrame.StyledPanel)
        block.setFixedWidth(400)
        layout = QVBoxLayout()
        layout.setSpacing(4)
        name_label = QLabel("變量名稱")
        name_edit = QLineEdit(normalize_input(name))
        value_label = QLabel("變量內容")
        value_edit = QLineEdit(normalize_input(value))
        desc_label = QLabel("說明")
        desc_edit = QLineEdit(normalize_input(desc))
        delete_btn = QPushButton("🗑️ 刪除")
        delete_btn.setFixedWidth(70)

        layout.addWidget(name_label)
        layout.addWidget(name_edit)
        layout.addWidget(value_label)
        layout.addWidget(value_edit)
        layout.addWidget(desc_label)
        layout.addWidget(desc_edit)
        layout.addWidget(delete_btn, alignment=Qt.AlignRight)
        layout.setContentsMargins(0, 0, 5, 0)
        block.setLayout(layout)

        index = len(self.env_blocks)
        row = index // 2
        col = index % 2
        self.env_grid.addWidget(block, row, col)

        self.env_blocks.append({
            "id": var_id,
            "frame": block,
            "name": name_edit,
            "value": value_edit,
            "desc": desc_edit,
            "delete": delete_btn
        })

        def remove_block():
            if var_id:
                database.delete_variable(var_id)
            block.setParent(None)
            self.env_blocks = [b for b in self.env_blocks if b["frame"] != block]
            self.rebuild_env_grid()

        delete_btn.clicked.connect(remove_block)

    def rebuild_env_grid(self):
        for i in reversed(range(self.env_grid.count())):
            item = self.env_grid.itemAt(i)
            widget = item.widget()
            if widget:
                self.env_grid.removeWidget(widget)
        for idx, b in enumerate(self.env_blocks):
            row = idx // 2
            col = idx % 2
            row = idx // 2
            col = idx % 2
            self.env_grid.addWidget(b['frame'], row, col)

    def save_all_variables(self):
        for b in self.env_blocks:
            name = b["name"].text()
            value = b["value"].text()
            desc = b["desc"].text()
            if b["id"] is None:
                database.insert_variable(name, value, desc)
            else:
                database.update_variable(b["id"], name, value, desc)
        from PyQt5.QtWidgets import QMessageBox
        QMessageBox.information(self, "儲存成功", "變量資料已成功儲存！")
