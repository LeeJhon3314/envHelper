from PyQt5.QtWidgets import QWidget, QVBoxLayout, QScrollArea, QFrame, QLabel, QLineEdit, QPushButton, QHBoxLayout, QSizePolicy, QMessageBox
from .shared import normalize_input
import database

class ToolsTabMixin:
    def build_tools_tab(self):
        self.tool_blocks = []

        widget = QWidget()
        layout = QVBoxLayout(widget)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFixedHeight(500)

        container = QWidget()
        self.tools_layout = QVBoxLayout(container)
        self.tools_layout.setSpacing(10)
        container.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        scroll.setWidget(container)

        tools = database.get_all_tools()
        if tools:
            for t in tools:
                self.add_tool_row(name=t[1], version=t[2], desc=t[3])
        else:
            for _ in range(3):
                self.add_tool_row()

        layout.addWidget(scroll)

        add_button = QPushButton("追加工具")
        add_button.clicked.connect(self.add_tool_row)
        layout.addWidget(add_button)

        return widget

    def add_tool_row(self, name="", version="", desc=""):
        row = QFrame()
        row.setFrameShape(QFrame.StyledPanel)
        row.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Maximum)

        row_layout = QHBoxLayout(row)

        name_input = QLineEdit()
        name_input.setPlaceholderText("工具名稱")
        name_input.setText(name)
        name_input.setFixedWidth(200)

        version_input = QLineEdit()
        version_input.setPlaceholderText("版本")
        version_input.setText(version)
        version_input.setFixedWidth(100)

        desc_input = QLineEdit()
        desc_input.setPlaceholderText("說明")
        desc_input.setText(desc)

        row_layout.addWidget(name_input)
        row_layout.addWidget(version_input)
        row_layout.addWidget(desc_input)

        self.tools_layout.addWidget(row)
        self.tool_blocks.append(row)
