from PyQt5.QtWidgets import QApplication
from ui_main import MainWindow
import database

if __name__ == "__main__":
    import sys
    database.init_db()
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
