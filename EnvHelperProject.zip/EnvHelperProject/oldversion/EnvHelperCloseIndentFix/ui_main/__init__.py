from .env_tab import EnvTabMixin
from .tools_tab import ToolsTabMixin
from .process_tab import ProcessTabMixin
from .faq_tab import FaqTabMixin
from .filepaths_tab import FilepathsTabMixin
from PyQt5.QtWidgets import QMainWindow, QTabWidget

class MainWindow(QMainWindow, EnvTabMixin, ToolsTabMixin, ProcessTabMixin, FaqTabMixin, FilepathsTabMixin):

    def closeEvent(self, event):
        reply = QMessageBox.question(
            self,
            "確認儲存",
            "是否儲存所有變更後關閉？",
            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel
        )
        if reply == QMessageBox.Yes:
            self.save_all_variables(silent=True)
            self.save_tools(silent=True)
            self.save_process_steps(silent=True)
            self.save_faq(silent=True)
            self.save_filepaths(silent=True)
        QMessageBox.information(self, "儲存成功", "所有資料已成功儲存。")
        event.accept()
        elif reply == QMessageBox.No:
            event.accept()
        else:
            event.ignore()
    def __init__(self):
        super().__init__()
        self.setWindowTitle("環境建置助手")
        self.setMinimumSize(900, 600)
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)
        self.env_blocks = []
        self.tool_blocks = []
        self.flow_blocks = []
        self.init_tabs()

    def init_tabs(self):
        self.tabs.addTab(self.build_env_tab(), "環境變量")
        self.tabs.addTab(self.build_tools_tab(), "工具清單")
        self.tabs.addTab(self.build_process_tab(), "作業流程")
        self.tabs.addTab(self.build_faq_tab(), "常見問題")
        self.tabs.addTab(self.build_filepaths_tab(), "檔案路徑")

    def build_placeholder_tab(self, label):
        from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel
        widget = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(QLabel(f"{label} 功能待建置"))
        widget.setLayout(layout)
        return widget
