def normalize_input(val):
    return "" if val in (None, False) else str(val)
