from PyQt5.QtWidgets import QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QScrollArea

class ToolsTabMixin:
    def build_tools_tab(self):
        container = QWidget()
        layout = QVBoxLayout(container)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)

        self.tools_content = QWidget()
        self.tools_layout = QVBoxLayout(self.tools_content)
        self.tools_content.setLayout(self.tools_layout)

        scroll_area.setWidget(self.tools_content)
        layout.addWidget(scroll_area)

        # Add control button (optional)
        add_button = QPushButton("新增工具")
        add_button.clicked.connect(self.add_tool_block)
        layout.addWidget(add_button)
        self.add_tool_block()  # 預先新增一個欄位

        return container

    def add_tool_block(self):
        row = QWidget()
        row_layout = QVBoxLayout(row)

        name_input = QLineEdit()
        name_input.setPlaceholderText("工具名稱")

        row_layout.addWidget(name_input)

        self.tools_layout.addWidget(row)
        self.tool_blocks.append(row)
